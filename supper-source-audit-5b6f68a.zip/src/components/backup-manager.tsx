"use client";
import { Download, RotateCcw } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "./ui/button";
export function BackupManager({ backups, description }: { backups: string[]; description: string }) {
  const [busy, setBusy] = useState("");

  async function restore(backup: string) {
    if (!confirm(`Restore ${backup}? The current active value will be preserved first.`)) return;
    setBusy(backup);
    try {
      const response = await fetch("/api/settings/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ backup }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      if (result.warning) toast.warning(result.warning);
      else toast.success(`Restored ${result.target}`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Restore failed");
    } finally {
      setBusy("");
    }
  }

  return <div className="overflow-hidden rounded-lg border bg-white">
    <div className="flex items-center justify-between border-b px-4 py-3">
      <div><p className="font-semibold text-slate-800">JSON backups</p><p className="mt-1 text-[10px] text-slate-400">{description}</p></div>
      <Button variant="outline" size="sm" asChild><a href="/api/export"><Download size={14} />Export all to Excel</a></Button>
    </div>
    {backups.length ? <div className="max-h-[560px] divide-y overflow-y-auto">{backups.map((backup) => <div key={backup} className="flex items-center justify-between gap-3 px-4 py-3"><div className="min-w-0"><p className="truncate text-[11px] font-medium text-slate-700">{backup.split("/").pop()}</p><p className="mt-1 truncate text-[10px] text-slate-400">{backup}</p></div><Button variant="ghost" size="sm" disabled={!!busy} onClick={() => restore(backup)}><RotateCcw size={13} />{busy === backup ? "Restoring..." : "Restore"}</Button></div>)}</div> : <div className="p-10 text-center text-[12px] text-slate-400">No active backups yet. The first supported data change will create one.</div>}
  </div>;
}
